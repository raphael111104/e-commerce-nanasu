
  # Nanasu_E-Commerce

  This is a code bundle for Nanasu_E-Commerce. The original project is available at https://www.figma.com/design/4aCdp3iz3dnfS7w83f2b7u/Nanasu_E-Commerce.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  